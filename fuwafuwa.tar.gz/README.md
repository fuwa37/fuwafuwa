Menjalankan aplikasi:
1. Jalankan fuwafuwa.exe